<?php

namespace Modules\Blog\Livewire\Pages;

use Livewire\Component;

class PostsIndex extends Component
{
    public function render()
    {
        return view('blog::livewire.pages.posts-index');
    }
}
