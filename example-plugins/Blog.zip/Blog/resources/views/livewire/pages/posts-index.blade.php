<div>
    <h3>The <code>PostsIndex</code> livewire component is loaded from the <code>Blog</code> module.</h3>
</div>
