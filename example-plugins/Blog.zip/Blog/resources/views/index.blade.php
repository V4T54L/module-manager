<x-blog::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('blog.name') !!}</p>
</x-blog::layouts.master>
