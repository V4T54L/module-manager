<flux:navlist.item :href="route('users.home')" :current="request()->routeIs('users.home')" wire:navigate>
    {{ __('Users Home') }}</flux:navlist.item>
