<x-users::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('users.name') !!}</p>
</x-users::layouts.master>
