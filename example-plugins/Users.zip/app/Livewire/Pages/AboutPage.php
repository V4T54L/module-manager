<?php

namespace Modules\Users\Livewire\Pages;

use Livewire\Component;

class AboutPage extends Component
{
    public function render()
    {
        return view('users::livewire.pages.about-page');
    }
}
